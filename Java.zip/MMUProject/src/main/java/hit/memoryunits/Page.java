package hit.memoryunits;

public class Page<T> extends java.lang.Object {
	private T content;
	
	private java.lang.Long pageId;
	
	public Page (java.lang.Long id, T content) {
		this.setPageId(id);
		this.setContent(content);
	}
	
	@Override
	public boolean equals(java.lang.Object obj) {
		return false;
	}

	public T getContent() {
		return content;
	}

	public void setContent(T content) {
		this.content = content;
	}

	public java.lang.Long getPageId() {
		return pageId;
	}

	public void setPageId(java.lang.Long pageId) {
		this.pageId = pageId;
	}
	
	@Override
	public int hashCode() {
		return 0;
	}
	
	@Override
	public java.lang.String toString() {
		return null;
	}
	

}
