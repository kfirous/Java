package hit.memoryunits;

public class RAM extends java.lang.Object {
	private int initialCapacity;
	
	private java.util.Map<java.lang.Long, Page<byte[]>> pages;
	
	public RAM(int initialCapacity) {
		this.setInitialCapacity(initialCapacity);
	}
	
	public void addPage(Page<byte[]> addPage) {
		
	}
	
	public void addPages(Page<byte[]>[] addPages) {
		
	}

	public int getInitialCapacity() {
		return initialCapacity;
	}

	public void setInitialCapacity(int initialCapacity) {
		this.initialCapacity = initialCapacity;
	}
	
	public Page<byte[]> getPage(int pageId) {
		return null;
	}
	
	public Page<byte[]> [] getPages(java.lang.Long[] pageIds) {
		return null;
	}
	
	public void removePage(Page<byte[]> removePage) {
		
	}
	
	public void removePages(Page<byte[]>[] removePages) {
		
	}
	
	
}
