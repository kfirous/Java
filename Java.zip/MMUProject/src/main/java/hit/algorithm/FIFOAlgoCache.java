package hit.algorithm;

import java.util.LinkedHashMap;
import java.util.LinkedList;
import java.util.Queue;

public class FIFOAlgoCache<K,V> extends LinkedHashMap<K,V> implements IAlgoCache<K,V> {

	private LinkedHashMap<K, V> cache;
	
	private Queue<K> keyQueue;
	
	private int capacity;
	
	public FIFOAlgoCache(int capasity) {
		cache = new LinkedHashMap<>(capacity);
		keyQueue = new LinkedList<K>();
		this.capacity = capasity;
	}
	
	@Override
	public V getElement(K key) {
		if (cache.containsKey(key)) {
			return cache.get(keyQueue.peek());
		}
		
		return null;
	}

	@Override
	public V putElement(K key, V value) {
		V valueToReturn = null;
		
		if (cache.size() == capacity) {
			K keyToRemove = keyQueue.poll();
			valueToReturn = cache.get(keyToRemove);
			cache.remove(keyToRemove);
		}
		
		cache.put(key, value);
		keyQueue.add(key);
		
		return valueToReturn;
	}

	@Override
	public void removeElement(K key) {
		cache.remove(keyQueue.poll());
	}
}
