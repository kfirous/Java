package hit.algorithm;

public interface IAlgoCacheTest {

}
